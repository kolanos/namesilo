========
NameSilo
========

A simple wrapper for the NameSilo_ API.

.. _NameSilo: http://www.namesilo.com
